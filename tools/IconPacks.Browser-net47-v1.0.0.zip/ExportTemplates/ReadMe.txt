﻿

You can use the following parameters inside the template:
  - @PageWidth
  - @PageHeight
  - @PathData
  - @FillColor
  - @StrokeColor
  - @StrokeWidth
  - @StrokeLineCap
  - @StrokeLineJoin
  - @TransformMatrix
  - @Background
  
 Additionaly you can provide these informations e.g. as a comment
  - @IconPackName
  - @IconKind
  - @IconPackLicense
  - @IconPackHomepage